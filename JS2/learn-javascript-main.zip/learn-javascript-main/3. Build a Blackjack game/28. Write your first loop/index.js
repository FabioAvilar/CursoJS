

// Create a for loop that counts from 10 to 100 in steps of 10
// Use console.log to log out the numbers
