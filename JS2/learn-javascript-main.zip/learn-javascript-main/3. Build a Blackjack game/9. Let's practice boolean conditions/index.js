console.log(4 === 3)  // 
console.log(5 > 2)    // 
console.log(12 > 12)  //
console.log(3 < 0)    //
console.log(3 >= 3)   // 
console.log(11 <= 11) //
console.log(3 <= 2)   //

// let firstCard = 10
// let secondCard = 11
// let sum = firstCard + secondCard
// let hasBlackJack = false
// let isAlive = true

// if (sum <= 20) {
//     console.log("Do you want to draw a new card? 🙂")
// } else if (sum === 21) {
//     console.log("Wohoo! You've got Blackjack! 🥳")
//     hasBlackJack = true
// } else {
//     console.log("You're out of the game! 😭")
//     isAlive = false
// }

// console.log(isAlive)