let firstCard = 6
let secondCard = 9
let sum = firstCard + secondCard

