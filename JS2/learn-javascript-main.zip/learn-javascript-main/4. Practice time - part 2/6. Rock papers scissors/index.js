let hands = ["rock", "paper", "scissor"]

// Create a function that returns a random item from the array


