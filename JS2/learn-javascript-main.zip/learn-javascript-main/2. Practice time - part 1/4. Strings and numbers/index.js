// Try to predict what each of the lines will log out
console.log("2" + 2) //
console.log(11 + 7) //
console.log(6 + "5") //
console.log("My points: " + 5 + 9) //
console.log(2 + 2) // 
console.log("11" + "14") // 
