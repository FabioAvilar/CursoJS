// Use .innerHTML to render a Buy! button inside the div container


