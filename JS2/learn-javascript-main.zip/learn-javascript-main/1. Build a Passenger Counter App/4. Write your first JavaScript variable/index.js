// document.getElementById("count").innerText = 5

let count = 0

console.log(count)


// 1. Create a variable, myAge, and set its value to your age

// 2. Log the myAge variable to the console